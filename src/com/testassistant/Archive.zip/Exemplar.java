package com.testassistant;

import java.io.IOException;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;

public class Exemplar {
		public static void main(String[] args) throws IOException {
			String path = System.getProperty("user.dir") + "/Test.pdf";
			PdfDocument pdf = new PdfDocument(new PdfWriter(path));
			Document document = new Document(pdf); 
			String line = "Hello! Welcome to iTextPdf";
			document.add(new Paragraph(line));
			document.add(new Paragraph("DON'T BE BLANK"));
			document.close();

		}

	}



